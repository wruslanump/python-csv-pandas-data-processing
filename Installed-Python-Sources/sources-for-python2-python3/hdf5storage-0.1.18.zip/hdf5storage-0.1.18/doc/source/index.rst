.. hdf5storage documentation master file, created by
   sphinx-quickstart on Sun Dec 22 00:05:54 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to hdf5storage's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   information
   introduction
   compression
   storage_format
   development
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

