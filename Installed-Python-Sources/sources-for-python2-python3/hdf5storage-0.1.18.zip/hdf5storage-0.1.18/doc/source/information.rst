===========
hdf5storage
===========

.. include:: ../../README.rst
