 --------------------------------------------------------------------

      BITSCOPE LOGIC - MIXED SIGNAL TIMING AND PROTOCOL ANALYZER

                        BETA Version 1.2

              http://www.bitscope.com/software/logic/

   Copyright (C) 2015 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------

 BitScope Logic is a mixed signal logic analyzer and protocol decoder.

 It uses the high speed data capture of BitScope to realise a powerful
 easy to use multi-channel mixed signal serial protocol analyzer which
 includes customizable logic  triggers, timing cursors, zoom controls,
 logic timing diagrams, automatic  packet decoding and analog waveform
 display. The supported protocols include CAN, SPI, I2C or UART serial
 signals in this release with other protocols added by popular demand.

 Operation is fast and intuitive, simply point, click, zoom and drag.

 Logic is compatible with Windows (XP to 7), Linux and (soon) OSX.
 
 --------------------------------------------------------------------
 PACKAGE INSTALLTION                                    (.deb or .rpm)

 If you're using the .deb or .rpm versions of the archive install the
 package file as you normally do for any other package on your system.

 When Logic is installed a new desktop menu item should appear in
 (probably in "Other") from where you can run the application.

 You can also run it by typing bitscope-logic in an xterm.

 NOTE: In recent editions of Fedora  there is a reported problem that
 results in a clash between our package and the filesystem package.We
 are working on a fix  for this but there is a  work-around which can 
 executed from a terminal in the meantime as:

   $ rpm -i bitscope* --force # force install the bitscope package
   $ yum reinstall filesystem # reinstall the filesystem package

 --------------------------------------------------------------------
 TARBALL INSTALLATION                                          (.tgz)

 If you've download the .tgz archive, unpack it somehere convenient.

 You can run Logic from  inside the unpacked archive (simply type
 ./bitscope-logic) or  you can copy the  executable to /usr/local/bin
 to "install it".

 Nothing else needs to be done to  use it but you will need to ensure
 you have X  and Gtk2 installed on your system. If  you use Gnome all
 you need will  be installed already. If you run KDE  you may need to
 install some libraries; the complete list of library dependencies is
 libatk1.0 libc6 libglib2.0 libgtk2.0 libpango1.0 and libx11-6.

 --------------------------------------------------------------------
 DEVICE SETUP

 Under most circumstances you  should not need to configure Logic
 to be able to connect with BitScope. Just click the CONNECT button,
 or press Ctrl-C.

 If your BitScope is not found  by Logic but you know where it is
 (eg /dev/ttyUSB3) click SETUP  and choose the appropriate connection
 (USB and /dev/ttyUSB3 in this example).

 Please see the following for more information about device setup:

   http://bitscope.com/software/driver/?p=lin
   http://bitscope.com/net/?p=config
 
 --------------------------------------------------------------------
 OPERATING INSTRUCTIONS
 
 Online help is available for Logic. 

 Just click the BitScope Logic Logo or press F1 when Logic is running.

 The documentation is editable as you read it so if you want to make
 notes or change it as you learn to use Logic you can.

 Send any comments, bug reports, suggestions to support@bitscope.com.
 
 For full details of bug fixes see the FIX.txt file.
 --------------------------------------------------------------------
                BitScope Designs. Jun 25, 2015.
 --------------------------------------------------------------------
